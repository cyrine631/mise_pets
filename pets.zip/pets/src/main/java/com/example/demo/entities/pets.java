package com.example.demo.entities;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class pets {
	
	@Id
	@GeneratedValue ( strategy = GenerationType.IDENTITY)
	private long idepet;
	private String nompet;
	private String categoriepet;
	private String famillepet;
	private double prixpet;
	
	
	public long getIdepet() {
		return idepet;
	}
	public void setIdepet(long idepet) {
		this.idepet = idepet;
	}
	public String getNompet() {
		return nompet;
	}
	public void setNompet(String nompet) {
		this.nompet = nompet;
	}
	public String getCategoriepet() {
		return categoriepet;
	}
	public void setCategoriepet(String categoriepet) {
		this.categoriepet = categoriepet;
	}
	public String getFamillepet() {
		return famillepet;
	}
	public void setFamillepet(String famillepet) {
		this.famillepet = famillepet;
	}
	public double getPrixpet() {
		return prixpet;
	}
	public void setPrixpet(double prixpet) {
		this.prixpet = prixpet;
	}
	public pets() {
		super();
		// TODO Auto-generated constructor stub
	}
	public pets(String nompet, String categoriepet, String famillepet, double prixpet) {
		super();
		this.nompet = nompet;
		this.categoriepet = categoriepet;
		this.famillepet = famillepet;
		this.prixpet = prixpet;
	}
	@Override
	public String toString() {
		return "pets [idepet=" + idepet + ", nompet=" + nompet + ", categoriepet=" + categoriepet + ", famillepet="
				+ famillepet + ", prixpet=" + prixpet + "]";
	}
	
}
