package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.example.demo.entities.pets;
import com.example.demo.repos.PetsRepository;

@Service
public class Petserviceimp implements Petservice  {

	@Autowired
	PetsRepository petRepository;
	
	@Override
	public pets savePets(pets pets) {
	return petRepository.save(pets);
	}
	
	@Override
	public pets updatePets(pets pets) {
	return petRepository.save(pets);
	}
	
	@Override
	public void deletePets(pets pets) {
		petRepository.delete(pets);
	}
	
	@Override
	public void deletePetById(Long id) {
		petRepository.deleteById(id);
	}

	@Override
	public pets getPet(Long id) {
	return petRepository.findById(id).get();
	}
	
	@Override
	public List<pets> getAllPets() {
	return petRepository.findAll();
	}
	
	@Override
	public Page<pets> getAllpetsParPage(int page, int size) {
	return petRepository.findAll(PageRequest.of(page, size));
	}
	
}
